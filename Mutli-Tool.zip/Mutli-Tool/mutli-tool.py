import random
import os
import time
import requests
import getpass


class main:

    def main():
            titles = ["Free mutlti-tool V1","Free multi-tool","Best tool in com."]

            os.system(f'title {random.choice(titles)}')

            print('Free Mutli-Tool\n[1]IP-Lookup\n[2]Xbox Resolver\n[3]Discord Token Bruteforcers')

            option = input(f'[{getpass.getuser()}]@Skids: ')
            
            if option == "1":
                
                print(f'Please enter a IP Address\n')
                ip = input(f': ')

                r=requests.get(f'"https://api.hackertarget.com/geoip/?q={ip}')
                print(r.json)
                input('Press enter to go back')

                os.system('cls||clear')

                main()


main()
